﻿Public Class Form22
    Private Sub Form22_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class